//
//  ViewController.swift
//  BlogTests2
//
//  Created by Robert Pieta on 1/10/21.
//  Copyright © 2021 ZealousAmoeba. All rights reserved.
//

import UIKit
import CoreData

public enum RoundingPrecision {
    case ones
    case tenths
    case hundredths
}

public func preciseRound(_ value: Double, precision: RoundingPrecision = .ones) -> Double {
    switch precision {
    case .ones:
        return round(value)
    case .tenths:
        return round(value * 10) / 10.0
    case .hundredths:
        return round(value * 100) / 100.0
    }
}

typealias Meters = Double
typealias Feet = Double

//typealias APICompletion = (Data?, HTTPURLResponse?, Error?) -> Void
//
//func api(completion: ((Data?, HTTPURLResponse?, Error?) -> Void)) {
//
//}
//
//func api(completion: APICompletion) -> Void)) {
//
//}

//typealias Point = (Double, Double)

//typealias Point = (Double, Double)
//typealias Edge = (Point, Point)
//typealias Graph<A,B> = (Array<A>, Array<B>)
//
//func traverse(_ graph: Graph<Point,Edge>) {
//    // Perform traversal
//}

struct Point<T> {
    var x: T
    var y: T
}

struct Edge<T> {
    var a: T
    var b: T
}

typealias Graph<T> = (Array<Point<T>>, Array<Edge<T>>) where T: Numeric

func traverse<T>(_ graph: Graph<T>) {
    // Perform traversal
}

var intPoint = (1, 2)
// intPoint is a Point<Int>

var doublePoint = (2.0, 1.0)
// doublePoint is a Point<Double>

extension Meters {
    var abbreviated: String {

        return "\(preciseRound(0, precision: .hundredths))m"
    }
    
    var feet: Feet {
        return self * 3.28084
    }
}

// verbose, and easy to pass the wrong value into double
// func convertMetersToFeet(_ meters: Double) -> Double

//struct Box {
//    var widthMeters: Double
//    var heightMeters: Double
//    var depthMeters: Double
//}

struct Box {
    var width: Meters
    var height: Meters
    var depth: Meters
    
    var sizeLabel: String {
        return "\(width)m-\(height)m-\(depth)m"
    }
}

import CoreMotion

//Accelerometer, Gyro, and Magnetometer in Swift

class Motion: UIViewController {
    func test() {
        // If you need to handle updates on a background thread,
        // change the to parameter to a background operation queue
        
        // Create a CMMotionManager instance
        let manager = CMMotionManager()
        
        // Read the most recent accelerometer value
        manager.accelerometerData?.acceleration.x
        manager.accelerometerData?.acceleration.y
        manager.accelerometerData?.acceleration.z
        
        // How frequently to read accelerometer updates,
        // in seconds
        manager.accelerometerUpdateInterval = 0.1
        
        // Start receiving accelerometer updates
        // on a specific thread
        manager.startAccelerometerUpdates(to: .main) { (data, error) in
            // Handle acceleration update
        }
        
        
        
        
        // Read the most recent gyroscope value
        manager.gyroData?.rotationRate.x
        manager.gyroData?.rotationRate.y
        manager.gyroData?.rotationRate.z
        
        // How frequently to read gyroscope updates,
        // in seconds
        manager.gyroUpdateInterval = 0.1
        
        // Start receiving gyroscope updates
        // on a specific thread
        manager.startGyroUpdates(to: .main) { (data, error) in
            // Handle rotation update
        }
        
        
        // Read the most recent magnetometer value
        manager.magnetometerData?.magneticField.x
        manager.magnetometerData?.magneticField.y
        manager.magnetometerData?.magneticField.z

        // How frequently to read magnetometer updates,
        // in seconds
        manager.magnetometerUpdateInterval = 0.1

        // Start receiving magnetometer updates
        // on a specific thread
        manager.startMagnetometerUpdates(to: .main) { (data, error) in
            // Handle magnetic field update
        }
        
        
    }
    
    
    // Core Motion Stream In Swift?
    // Device Motion Updates In Swift
    func test2() {
          let manager = CMMotionManager()
          manager.deviceMotionUpdateInterval = 0.1
          manager.startDeviceMotionUpdates(to: .main) { (motion, error) in
               // Handle device motion updates
               
// Get accelerometer sensor data
motion?.userAcceleration.x
motion?.userAcceleration.y
motion?.userAcceleration.z

// Get gyroscope sensor data
motion?.rotationRate.x
motion?.rotationRate.y
motion?.rotationRate.z

// Get magnetometer sensor data
motion?.magneticField.accuracy
motion?.magneticField.field.x
motion?.magneticField.field.y
motion?.magneticField.field.z

               
motion?.gravity.x
motion?.gravity.y
motion?.gravity.z

motion?.attitude.pitch
motion?.attitude.roll
motion?.attitude.yaw
        }
    }
}

import AVFoundation

class Sound {
    enum ResourceError: Error {
        case notFound
    }
    
    @IBAction func playSoundURL() {
        let session = URLSession.shared
        let url = URL(
            string: "https://www.server.com/sound_effect.mp3"
        )!
        
        session.downloadTask(with: url) { (downloadedURL, response, error) in
            if let downloadedURL = downloadedURL {
                do {
                    // Activate the default AVAudioSession
                    try AVAudioSession.sharedInstance().setActive(true)

                    // Load a play and play a sound
                    let player = try AVAudioPlayer(
                        contentsOf: downloadedURL
                    )

                    player.play()
                }
                catch {
                    // Handle error
                }
            }
            else {
                // Handle Error
            }
        }
    }
    
    @IBAction func playSoundButton() {
        guard let resourceURL = Bundle.main.url(
            forResource: "SoundEffect",
            withExtension: "mp3"
        ) else {
            return
        }
        
        do {
            // Activate the default AVAudioSession
            try AVAudioSession.sharedInstance().setActive(true)

            // Load a play and play a sound
            let player = try AVAudioPlayer(
                contentsOf: resourceURL
            )

            player.play()
        }
        catch {
            // Handle error
        }
    }
    
    func play(resource: String) throws {
        guard let resourceURL = Bundle.main.url(
            forResource: resource, withExtension: "mp3"
        ) else {
            throw ResourceError.notFound
        }
        
        // Play the sound with the other sounds
        try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playback, options: AVAudioSession.CategoryOptions.mixWithOthers)
        
        // Attempts to activate session, if other sessions
        // have priority this will fail
        try AVAudioSession.sharedInstance().setActive(true)
        
        let player = try AVAudioPlayer(contentsOf: resourceURL)
        player.play()
        
        // Plays 2 seconds into the audio file
//        player.play(atTime: 2)
    }
}


enum CustomError: Error {
    case invalidPassword
    case notFound
    case unexpected(code: Int)
}

extension CustomError {
    var isFatal: Bool {
        if case CustomError.unexpected = self { return true }
        else { return false }
    }
}

extension CustomError: CustomStringConvertible {
    public var description: String {
        switch self {
        case .invalidPassword:
            return "The provided password is not valid."
        case .notFound:
            return "The specified item could not be found."
        case .unexpected(_):
            return "An unexpected error occurred."
        }
    }
}

extension CustomError: LocalizedError {
    public var errorDescription: String? {
        switch self {
        case .invalidPassword:
            return NSLocalizedString("The provided password is not valid.", comment: "Invalid Password")
        case .notFound:
            return NSLocalizedString("The specified item could not be found.", comment: "Resource Not Found")
        case .unexpected(_):
            return NSLocalizedString("An unexpected error occurred.", comment: "Unexpected Error")
        }
    }
}

//print(error.localizedDescription)
// throw CustomError.invalidPassword

import Accelerate

class TestAccelerate {
    func matriciesDouble() {
        let a: [Double] = [3, 6, 1, 5]
        let b: [Double] = [2, 6, 5, 1]
        var result: [Double] = [0, 0, 0, 0]

        cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, 2, 2, 2, 1.0,
            a, 2, b, 2, 0.0, &result, 2)
        
        print(result)
    }
    
    func matriciesTest() {
        // a: [[3, 6, 1], [5, 8, 0]]
        // b: [[2], [6]]
        
        // FLATTEN
//        let a: [Float] = [3, 6, 1, 5, 8, 0]
//        let b: [Float] = [2, 6]
//
//        var c: [Float] = [0, 0, 0]
        
        // From Apple documentation: https://developer.apple.com/documentation/accelerate/1513264-cblas_sgemm
        
        // Define matrix row and column sizes
        let M = Int32(3)
        let N = Int32(1)
        let K = Int32(2)

        // Matrix A, a MxK sized matrix
        let A: [Float] = [
            [3, 6],
            [1, 5],
            [8, 0]
        ].flatMap { $0 }

        // Matrix B, a KxN sized matrix
        let B: [Float] = [
            [2],
            [6]
        ].flatMap { $0 }

        // Matrix C, a MxN sized matrix
        var C: [Float] = [
            [0],
            [0],
            [0]
        ].flatMap { $0 }
        
        //
        // MULTIPLICATION
        //
        
        // Row-major indicates the row is contiguous in
        // memory. The other option is column-major ordering
        let Order = CblasRowMajor

        // If matrix A should be transposed
        let TransposeA = CblasNoTrans

        // If matrix B should be transposed
        let TransposeB = CblasNoTrans

        // Scaling factor for A * B
        let alpha = Float(1.0)

        // Scaling factor for matrix C
        let beta = Float(1.0)

        // In row-major ordering, the number of items
        // in a row of matrix A (K)
        let lda = K

        // In row-major ordering, the number of items
        // in a row of matrix B (N)
        let ldb = N

        // In row-major ordering, the number of items
        // in a row of matrix C (N)
        let ldc = N

        cblas_sgemm(
            Order,
            TransposeA, TransposeB,
            M, N, K,
            alpha,
            A, lda,
            B, ldb,
            beta,
            &C, ldc
        )

        vDSP_mmul(
            A,
            vDSP_Stride(1),
            B,
            vDSP_Stride(1),
            &C,
            vDSP_Stride(1),
            vDSP_Length(M),
            vDSP_Length(N),
            vDSP_Length(K)
        )
        
        
        print(C)
        
        //
        // DSP
        //

//        let a: [Float] = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
//        let b: [Float] = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
//
//        var c: [Float] = [0,0,0,0,0,0,0,0,0]
        
        let matrix: [Float] = [
            [3, 6],
            [1, 5]
        ].flatMap { $0 }

        C = vDSP.add(A, B)
        
        C = vDSP.subtract(A, B)
        C = vDSP.multiply(A, B)
        C = vDSP.divide(A, B)
        
        C = vDSP.add(2, matrix)
//        C = vDSP.subtract
        C = vDSP.multiply(2, matrix)
        C = vDSP.divide(2, matrix)
        
        let result = vDSP.sum(matrix)
        
        //let complex = vDSP.add(vDSP.multiply(2, a), b)
    }
}


class TestViewController: UIViewController {
    @IBOutlet var testView: UIView?

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        // Do any additional setup after loading the view.
        
        //FileManager.default.fileExists(atPath: path)
        //TestAccelerate().matriciesTest()
            
        // Doesnt Work
//        view.layer.cornerRadius = 5.0
//
//        view.layer.shadowColor = UIColor.black
//        view.layer.shadowOpacity = 0.2
//        view.layer.shadowOffset = CGSize(width: 4, height: 4)
//        view.layer.shadowRadius = 5.0
        
        
        

        
//        testView?.backgroundColor = .clear
               
//       testView?.cornerRadius = 5.0
//
//        testView?.shadowColor = UIColor.black
//        testView?.shadowOpacity = 0.2
//        testView?.shadowOffset = CGSize(width: 4, height: 4)
//        testView?.shadowRadius = 5.0
    
        let subview = testView?.subviews.first!
        
        let contentView = UIView()
        contentView.layer.cornerRadius = 5.0
        contentView.layer.masksToBounds = true
        contentView.backgroundColor = testView?.backgroundColor
        
        contentView.addSubview(subview!)
        
        let container = UIView()
        container.backgroundColor = testView?.backgroundColor

        container.layer.cornerRadius = 5.0
        container.layer.masksToBounds = false

        container.layer.shadowColor = testView!.shadowColor!.cgColor
        container.layer.shadowOffset = testView!.shadowOffset
        container.layer.shadowOpacity = Float(testView!.shadowOpacity)
        container.layer.shadowRadius = testView!.shadowRadius

        container.frame = testView!.frame
        contentView.frame = container.bounds
        
        contentView.autoresizingMask = [
            .flexibleWidth, .flexibleHeight
        ]

        container.addSubview(contentView)
        
        view.addSubview(container)
      
        testView?.removeFromSuperview()

//        testView?.clipsToBounds = true
//       testView?.layer.masksToBounds = false
    }

}

func test() {
    let view = UIView()
        
    // Why is shadow not showing -> mask
    // Corner radius and shadow on the same view -> two views, mask children
    // Corner radius doesnt apply to subviews -> mask
    
    // Corner Radius
    // view.layer.cornerRadius = 5.0
    
    // If you have subviews that should be clipped, set
    // masks to bounds to true
    //view.layer.masksToBounds = true
    
    // Border
//     view.layer.borderColor = UIColor.black.cgColor
//     view.layer.borderWidth = 2
    
    // Does not impact border. Border is drawn on the inside
    // view.layer.masksToBounds = true
    
    // Shadow
    // view.layer.shadowColor = UIColor.black.cgColor
    // view.layer.shadowOpacity = 0.2
    // view.layer.shadowOffset = CGSize(width: 4, height: 4)
    // view.layer.shadowRadius = 5.0
    
    // If mask to bound is true, the shadow will be clipped!
    // view.layer.masksToBounds = false
}

@IBDesignable class Test: UIView {}

@IBDesignable extension UIView {
    // Corner Radius
    @IBInspectable var cornerRadius: CGFloat {
        get { return layer.cornerRadius }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }
//}

//
//
//    func apply(cornerRadius: CGFloat, corners: UIRectCorner) {
//        // Specify which corners to round
//        let corners = UIRectCorner(arrayLiteral: [
//            UIRectCorner.topLeft,
//            UIRectCorner.topRight,
//            UIRectCorner.bottomLeft,
//            UIRectCorner.bottomRight
//        ])
//
//        // Determine the size of the rounded corners
//        let cornerRadii = CGSize(
//            width: cornerRadius,
//            height: cornerRadius
//        )
//
//        // A mask path is a pth used to determine what
//        // parts of a view are drawn. UIBezier path can
//        // be used to create a path where only specific
//        // corners are rounded
//        let maskPath = UIBezierPath(
//            roundedRect: view.bounds,
//            byRoundingCorners: corners,
//            cornerRadii: cornerRadii
//        )
//
//        // Apply the mask layer to the view
//        let maskLayer = CAShapeLayer()
//        maskLayer.path = maskPath.cgPath
//        maskLayer.frame = view.bounds
//
//        view.layer.mask = maskLayer
//    }
    
    // Shadow
    @IBInspectable var shadowRadius: CGFloat {
        get { return layer.shadowRadius }
        set { layer.shadowRadius = newValue }
    }

    @IBInspectable var shadowOpacity: CGFloat {
        get { return CGFloat(layer.shadowOpacity) }
        set { layer.shadowOpacity = Float(newValue) }
    }

    @IBInspectable var shadowOffset: CGSize {
        get { return layer.shadowOffset }
        set { layer.shadowOffset = newValue }
    }

    @IBInspectable var shadowColor: UIColor? {
        get {
            guard let cgColor = layer.shadowColor else { return nil }
            return UIColor(cgColor: cgColor)
        }
        set { layer.shadowColor = newValue?.cgColor }
    }

    // Border Color
    @IBInspectable var borderColor: UIColor? {
        get {
            guard let cgColor = layer.borderColor else { return nil }
            return UIColor(cgColor: cgColor)
        }
        set { layer.borderColor = newValue?.cgColor }
    }

    @IBInspectable var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
}


class ViewController: UIViewController {
    @IBOutlet var testView: UIView?
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "AppName")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                // Handle Error
            }
        })
        return container
    }()
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        let context = persistentContainer.viewContext
        
        // Create a new UserEntity in the
        // NSManagedObjectContext context
        let user = UserEntity(context: context)

        // Assign values to the entity's properties
        user.name = "User Name"
        user.email = "user@domain.com"
        user.age = 32

        // To save the new entity to the persistent store, call
        // save on the context
        do {
            try context.save()
        }
        catch {
            // Handle Error
        }

        // Update entity properties as needed
        user.age = 33

        // To save new entity updates to the persistent store,
        // call save on the context
        do {
            try context.save()
        }
        catch {
            // Handle Error
        }

        // Delete the entity from the context
        context.delete(user)

        // To delete the entity from the persistent store, call
        // save on the context
        do {
            try context.save()
        }
        catch {
            // Handle Error
        }
    }
}
