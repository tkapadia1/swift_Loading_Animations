import UIKit
import Foundation

//Parse URL String
//    Parse Absolute URL
var url = URL(string: "https://advswift.com/api/v1?page=url+components")!
url.host // advswift.com
url.path // /api/v1


//    Parse Relative URL
var root = URL(string: "https://advswift.com/")!
var rel = URL(string: "api/v1?page=url+components", relativeTo: root)!

rel.host // advswift.com
rel.path // /api/v1

//    URLComponents
// URLComponents provides an interface to various URL properties, including parsing url query parameters.

//    Get Value Of URL Query Parameters
// URLComponents automatically decodes URL encoded strings
//var url = URL(string: "https://advswift.com/api/v1?page=url+components")!

var components = URLComponents(url: url, resolvingAgainstBaseURL: false)!
components.queryItems

// Decode URL
"url%20components".removingPercentEncoding

// URLComponents Automatically Decodes Query Items
var url02 = URL(string: "https://www.advancedswift.com/api/v1/endpoint?key=value&key2=value%202")

var components2 = URLComponents(url: url02!, resolvingAgainstBaseURL: false)
components2?.queryItems

//    What is resolvingAgainstBaseURL?
var components1 = URLComponents(url: rel, resolvingAgainstBaseURL: false)
components1?.string

var components3 = URLComponents(url: rel, resolvingAgainstBaseURL: true)
components3?.string

//
//Create URL String
var url6 = URLComponents()
url6.scheme = "https"
url6.host = "advswift.com"
url6.path = "/home"

print(url6.string)

//    URL Encode A String
"google query".addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)

// URLComponents Automatically Encodes Query Items
var c = URLComponents()
c.queryItems = [
    URLQueryItem(name: "page", value: "url components")
]
c.string

//    Build A URL With Query Parameters
var new = URLComponents()
new.scheme = "https"
new.host = "www.advancedswift.com"
new.path = "/api/v1/endpoint"
new.queryItems = [
   URLQueryItem(name: "key3", value: "value3"),
   URLQueryItem(name: "key4", value: "value4")
]

print(new.url?.absoluteString)

//URL Examples
var url0 = URL(string: "https://advswift.com/home")

// URLs and Strings
// Absolute URL
var url1 = URL(string: "https://advswift.com/home")
url1?.absoluteURL // URL struct, https://advswift.com/home
url1?.absoluteString // https://advswift.com/home
url1?.baseURL // nil

// Relative URL
var url12 = URL(string: "v1/api", relativeTo: URL(string: "https://advswift.com"))
url12?.absoluteURL // URL struct, https://advswift.com/home/v1/api
url12?.absoluteString // https://advswift.com/v1/api
url12?.baseURL // URL struct, https://advswift.com

//    Port, Host, and Scheme
var url2 = URL(string: "https://advswift.com:80")!
url2.port! + 1 // 80
url2.host // advswift.com
url2.scheme // https

//    Query, and Fragment
var url31 = URL(string: "https://advswift.com/page?topic=swift&examples=true")!
url31.query // topic=swift&examples=true

var url32 = URL(string: "https://advswift.com/page#anchor")!
url32.fragment // anchor

//    Path, Path Components, and Extension
var url4 = URL(string: "https://advswift.com/api/v1/endpoint.ext")!
url4.path // /api/v1/endpoint.ext
url4.pathExtension // ext
url4.pathComponents // ["/", "api", "v1", "endpoint.ext"]

url4.relativePath // /api/v1/endpoint.ext
url4.relativeString // https://advswift.com/api/v1/endpoint.ext




