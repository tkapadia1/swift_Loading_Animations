import UIKit

// Each is an example you can adapt in your application

//// a@a.com
//// a.b-c@l-p.b
//let emailPattern = #"^\S+@\S+\.\S+$"#
//
//// "invalid test" does not match emailPattern, so
//// the result is nil
//var result = "invalid test".range(
//    of: emailPattern,
//    options: .regularExpression
//)
//
//// "test@test.com" matches emailPattern,
//// so result is a Range<String.Index>
//var result = "test@test.com".range(
//    of: emailPattern,
//    options: .regularExpression
//)
//
//let emailRegex = try! NSRegularExpression(
//    pattern: emailPattern,
//    options: []
//)
//
//let source = "invalid test"
//let sourceRange = NSRange(
//    source.startIndex..<source.endIndex,
//    in: source
//)
//
//// "invalid test" does not match emailPattern, so
//// the result is nil
//var result = emailRegex.matches(
//    in: source,
//    options: [],
//    range: sourceRange
//)
//
//let source = "test@test.com"
//let sourceRange = NSRange(
//    source.startIndex..<source.endIndex,
//    in: source
//)
//
//// "test@test.com" matches emailPattern,
//// so result is a [NSTextCheckingResult]
//var result = emailRegex.matches(
//    in: source,
//    options: [],
//    range: sourceRange
//)

//333-333 3333
//333 333 3333
//(333) 333-3333
//3333333333
let phonePattern = #"^\(?\d{3}\)?[ -]?\d{3}[ -]?\d{4}$"#

//// "333 44 12 2121" does not match phonePattern, so
//// the result is nil
//var result = "333 44 12 2121".range(
//    of: phonePattern,
//    options: .regularExpression
//)

//// "(567)-678 1231" matches emailPattern,
//// so result is a Range<String.Index>
//var result = "(567)-678 1231".range(
//    of: phonePattern,
//    options: .regularExpression
//)
//
//
//let phoneRegex = try! NSRegularExpression(pattern: phonePattern, options: [])
//phoneRegex.matches(in: "333 44 12 2121", options: [], range: "333 44 12 2121".fullRange)
//phoneRegex.matches(in: "(123) 123 1234", options: [], range: "(123) 123 1234".fullRange)
//
//let phoneRegex = try! NSRegularExpression(
//    pattern: phonePattern,
//    options: []
//)
//
//let source = "(567)-678 1231"
//let sourceRange = NSRange(
//    source.startIndex..<source.endIndex,
//    in: source
//)
//
//// "(567)-678 1231" matches phonePattern,
//// so result is a [NSTextCheckingResult]
//var result = phoneRegex.matches(
//    in: source,
//    options: [],
//    range: sourceRange
//)

// Requires first and last name, supporting middle names. Only letters and - accepted.
let usernamePattern = #"^[a-zA-Z-]+ .* ?[a-zA-Z-]+$"#

//"name n name".range(of: usernamePattern, options: .regularExpression)
//"n   ".range(of: usernamePattern, options: .regularExpression)
//"n o".range(of: usernamePattern, options: .regularExpression)

//// "FirstNameOnly" does not match usernamePattern, so
//// the result is nil
//var result = "FirstNameOnly".range(
//    of: usernamePattern,
//    options: .regularExpression
//)
//
//var validUsername = (result != nil)
//
//// "FirstName LastName" matches usernamePattern,
//// so result is a Range<String.Index>
//var result = "FirstName LastName".range(
//    of: usernamePattern,
//    options: .regularExpression
//)
//
//var validUsername = (result != nil)

//let nameRegex = try! NSRegularExpression(pattern: usernamePattern, options: [])
//nameRegex.matches(in: "name n name", options: [], range: "name n name".fullRange)
//nameRegex.matches(in: "n   ", options: [], range: "n   ".fullRange)
//nameRegex.matches(in: "n o", options: [], range: "n o".fullRange)

//let nameRegex = try! NSRegularExpression(
//    pattern: usernamePattern,
//    options: []
//)
//
//let source = "FirstName LastName"
//let sourceRange = NSRange(
//    source.startIndex..<source.endIndex,
//    in: source
//)
//
//// "FirstName LastName" matches usernamePattern,
//// so result is a [NSTextCheckingResult]
//var result = nameRegex.matches(
//    in: source,
//    options: [],
//    range: sourceRange
//)
//
//let validUsername = (result != nil)


// First and last name capture groups
// Example
// Check out this article for more how to implement [functionName] in Swift.

// ?= is a positive look ahead

// At least one capital, one lowercase, one number, and one special character
// At least 8 characters
let passwordPattern =
    // Match only if there are at least 8 characters
    #"(?=.{8,})"# +

    // Match only if there is at least one capital letter
    #"(?=.*[A-Z])"# +
        
    // Match only if there is at least one lowercase letter
    #"(?=.*[a-z])"# +
        
    // Match only if there is at least one digit
    #"(?=.*\d)"# +
        
    // Match only if there is at least one special character
    #"(?=.*[ !$%&?._-])"#

//// "weakpassword" does not match passwordPattern, so
//// the result is nil
//var result = "weakpassword".range(
//    of: passwordPattern,
//    options: .regularExpression
//)
//
//var validPassword = (result != nil)
//
//// "$tr0ngPa$$w0rd" matches passwordPattern,
//// so result is a Range<String.Index>
//var result = "$tr0ngPa$$w0rd".range(
//    of: passwordPattern,
//    options: .regularExpression
//)
//
//var validPassword = (result != nil)

//"Password4".range(of: passwordPattern, options: .regularExpression)

//let passwordRegex = try! NSRegularExpression(pattern: passwordPattern, options: [])
//passwordRegex.matches(in: "password", options: [], range: "password".fullRange)
//passwordRegex.matches(in: "Pa$$w0rd", options: [], range: "Pa$$w0rd".fullRange)
//passwordRegex.matches(in: "Password4", options: [], range: "Password4".fullRange)

//let passwordRegex = try! NSRegularExpression(
//    pattern: passwordPattern,
//    options: []
//)
//
//let source = "$tr0ngPa$$w0rd"
//let sourceRange = NSRange(
//    source.startIndex..<source.endIndex,
//    in: source
//)
//
//// "$tr0ngPa$$w0rd" matches passwordPattern,
//// so result is a [NSTextCheckingResult]
//var result = passwordRegex.matches(
//    in: source,
//    options: [],
//    range: sourceRange
//)
//
//let validPassword = (result != nil)

// 1/2/2021
// 02-3-2020
let datePattern = #"^\d{1,2}[\/-]\d{1,2}[\/-]\d{4}$"#

//"1/2/2021".range(of: datePattern, options: .regularExpression)

//// "Last Week" does not match datePattern, so
//// the result is nil
//var result = "Last Week".range(
//    of: datePattern,
//    options: .regularExpression
//)
//
//var validDate = (result != nil)
//
//// "02-3-2020" matches datePattern,
//// so result is a Range<String.Index>
//var result = "02-3-2020".range(
//    of: datePattern,
//    options: .regularExpression
//)
//
//var validDate = (result != nil)

//let dateRegex = try! NSRegularExpression(pattern: datePattern, options: [])
//dateRegex.matches(in: "Jan 2 2000", options: [], range: "Jan 2 2000".fullRange)
//dateRegex.matches(in: "1/2/2021", options: [], range: "1/2/2021".fullRange)
//dateRegex.matches(in: "02-3-2020", options: [], range: "02-3-2020".fullRange)

// date component capture groups
// Example
// Check out this article for more how to implement [functionName] in Swift.


//let dateRegex = try! NSRegularExpression(
//    pattern: datePattern,
//    options: []
//)
//
//let source = "02-3-2020"
//let sourceRange = NSRange(
//    source.startIndex..<source.endIndex,
//    in: source
//)
//
//// "02-3-2020" matches datePattern,
//// so result is a [NSTextCheckingResult]
//var result = dateRegex.matches(
//    in: source,
//    options: [],
//    range: sourceRange
//)
//
//let validDate = (result != nil)



// CAPTURE GROUPS ARTICLE
import Foundation

//let name = "firstName middleName lastName"
//let nameRange = NSRange(
//    name.startIndex..<name.endIndex,
//    in: name
//)
//
//// Create NSRegularExpression
//let capturePattern = #"([a-zA-Z-]+) ?.* ([a-zA-Z-]+)?"#
//let captureRegex = try! NSRegularExpression(
//    pattern: capturePattern,
//    options: []
//)
//
//// Find the matching capture groups
//let matches = captureRegex.matches(
//    in: name,
//    options: [],
//    range: nameRange
//)
//
//guard let match = matches.first else {
//    // Handle exception
//    throw NSError(domain: "", code: 0, userInfo: nil)
//}

//var names: [String] = []
//
//// For each matched range, extract the capture group
//for rangeIndex in 0..<match.numberOfRanges {
//    let matchRange = match.range(at: rangeIndex)
//
//    // Ignore matching the entire username string
//    if matchRange == nameRange { continue }
//
//    // Extract the substring matching the capture group
//    if let substringRange = Range(matchRange, in: name) {
//        let capture = String(name[substringRange])
//        names.append(capture)
//    }
//}
//
//names.first // firstName
//names.last // lastName


let birthday = "01/02/2003"
let birthdayRange = NSRange(
    birthday.startIndex..<birthday.endIndex,
    in: birthday
)

// Create NSRegularExpression
let capturePattern =
    #"(?<month>\d{1,2})\/"# +
    #"(?<day>\d{1,2})\/"# +
    #"(?<year>\d{1,4})"#

let birthdayRegex = try! NSRegularExpression(
    pattern: capturePattern,
    options: []
)

// Find the matching capture groups
let matches = birthdayRegex.matches(
    in: birthday,
    options: [],
    range: birthdayRange
)

guard let match = matches.first else {
    // Handle exception
    throw NSError(domain: "", code: 0, userInfo: nil)
}

var captures: [String: String] = [:]

// For each matched range, extract the named capture group
for name in ["month", "day", "year"] {
    let matchRange = match.range(withName: name)
    
    // Extract the substring matching the named capture group
    if let substringRange = Range(matchRange, in: birthday) {
        let capture = String(birthday[substringRange])
        captures[name] = capture
    }
}

captures["month"] // 01
captures["day"] // 02
captures["year"] // 2003
