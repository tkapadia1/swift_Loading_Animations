import UIKit
import PlaygroundSupport


fileprivate class CircularProgressLayer: CALayer {
    // NSManaged tells the compiler progress will have values
    // at runtime, removing the uninitialized compiler error
    @NSManaged var progress: CGFloat

    override class func needsDisplay(forKey key: String) -> Bool {
        if key == #keyPath(progress) { return true }
        return super.needsDisplay(forKey: key)
    }

    override func draw(in ctx: CGContext) {
        super.draw(in: ctx)

        UIGraphicsPushContext(ctx)
        
        var startAngle: CGFloat = 1.5 * .pi
        let twoPi: CGFloat = 2 * .pi
        let halfPi: CGFloat = .pi / 2.0
        

        let center = CGPoint(x: bounds.midX, y: bounds.midY)
        let strokeWidth: CGFloat = 6
        let radius = (bounds.size.width / 2) - strokeWidth
        let path = UIBezierPath(arcCenter: center, radius: radius, startAngle: 0, endAngle: twoPi, clockwise: true)
        path.lineWidth = strokeWidth


        //Red
        tintc
        UIColor.red.setStroke()

        var endAngle = (twoPi * progress) - halfPi
        var pathProgress = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: endAngle , clockwise: true)
        
        if progress > 1 {
            endAngle = twoPi - halfPi
            startAngle = (twoPi - halfPi) - (twoPi * (1-progress))
            
            pathProgress = UIBezierPath(arcCenter: center, radius: radius, startAngle: startAngle, endAngle: endAngle , clockwise: true)
        }
        pathProgress.lineWidth = strokeWidth
        pathProgress.lineCapStyle = .round
        pathProgress.stroke()

        UIGraphicsPopContext()
    }
}


class CircleLoading: UIView {
    public dynamic var progress: CGFloat = 0 {
        didSet {
            progressLayer.progress = progress
        }
    }

    fileprivate var progressLayer: CircularProgressLayer {
        return layer as! CircularProgressLayer
    }

    override public class var layerClass: AnyClass {
        return CircularProgressLayer.self
    }


    override public func action(for layer: CALayer, forKey event: String) -> CAAction? {
        if event == #keyPath(CircularProgressLayer.progress),
            let action = action(
                for: layer, forKey: #keyPath(backgroundColor)
            ) as? CAAnimation,
            let animation: CABasicAnimation = (action.copy() as? CABasicAnimation) {

            animation.keyPath = #keyPath(CircularProgressLayer.progress)
            animation.fromValue = progressLayer.progress
            animation.toValue = progress

            self.layer.add(
                animation,
                forKey: #keyPath(CircularProgressLayer.progress)
            )

            return animation
        }
        return super.action(for: layer, forKey: event)
    }
}

class Controller: UIViewController {
    override func viewDidLoad() {
        view.backgroundColor = .gray
        
        let circularProgress = CircleLoading(
            frame: CGRect(x: 0, y: 0, width: 80, height: 80)
        )

        circularProgress.backgroundColor = .clear
        view.addSubview(circularProgress)
        
        let rotateAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotateAnimation.fromValue = 0.0
        rotateAnimation.toValue = CGFloat(Double.pi * 2)
        rotateAnimation.isRemovedOnCompletion = false
        rotateAnimation.duration = 2
        rotateAnimation.repeatCount = Float.infinity
        circularProgress.layer.add(rotateAnimation, forKey: nil)
        
        let fillAnimation = CABasicAnimation(keyPath: "progress")
        fillAnimation.fromValue = 0.0
        fillAnimation.toValue = 2.0
        fillAnimation.isRemovedOnCompletion = false
        fillAnimation.duration = 4
        fillAnimation.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.easeOut)

        fillAnimation.repeatCount = Float.infinity
        circularProgress.layer.add(fillAnimation, forKey: nil)
    }
}


var c = Controller()
PlaygroundPage.current.liveView = c

