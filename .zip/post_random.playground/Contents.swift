
import UIKit
import Foundation

//Random Number Between Two Values
Int.random(in: 0..<100)

//Random number Between 0 And 1
Float.random(in: 0..<1)

//Swift Random Seed
//srand48 and drand48
//RandomNumberGenerator
//
//RandomNumberGenerator

struct RandomNumberGeneratorWithSeed: RandomNumberGenerator {
    init(seed: Int) {
        srand48(seed)
    }
    
    func next() -> UInt64 {
        return withUnsafeBytes(of: drand48()) { bytes in
            bytes.load(as: UInt64.self)
        }
    }
}

var g = RandomNumberGeneratorWithSeed(seed: 12)

Int.random(in: 0..<100, using: &g)
Float.random(in: 0..<1, using: &g)
[1,2,3,4].randomElement(using: &g)

drand48()
var s = CACurrentMediaTime()
for _ in 0..<2000 {
    Int.random(in: 0..<10000, using: &g)
}
print(CACurrentMediaTime() - s)

s = CACurrentMediaTime()
for _ in 0..<2000 {
    Int.random(in: 0..<10000)
}
print(CACurrentMediaTime() - s)

//Random Element From Array
[1,2,3,4].randomElement()

//Multiple Random Elements From Array
var array = [1,2,3,4,5]
var randomArray = array.shuffled()
var randomWithoutReplacement = randomArray.prefix(3)

//Multiple Random Elements From Array With Replacement
//var array = [1,2,3,4,5]
//var randomWithReplacement = (0..<10).map { _ in array.randomElement() }
//randomWithReplacement

//Random Value From Dictionary
var dictionary: [Int:String] = [
    1:"1", 2: "2", 3: "3", 4: "4", 5: "5"
]

// Random Key
dictionary.randomElement()?.key

// Random Value
dictionary.randomElement()?.value

//Multiple Random Values From Dictionary
//var randomKeys = dictionary.keys.shuffled()
//var randomValuesWithoutReplacement = randomKeys.map { key in dictionary[key] }

//Multiple Random Values From Dictionary With Replacement
var randomKeys = dictionary.keys.shuffled()
var randomValuesWithoutReplacement = (0..<10).map { index -> String in
    let key = dictionary.keys.randomElement()!
    return dictionary[key]!
}

// Random Key
//var randomWithReplacement = (0..<10).map { _ in dictionary.randomElement()?.key }
//randomWithReplacement

// Random Value
//var randomWithReplacement = (0..<10).map { _ in dictionary.randomElement()?.value }
//randomWithReplacement

//Generate Unique Random Numbers
var uniqueRandomNumbers: Set<Int> = []

while uniqueRandomNumbers.count < 1000 {
    let value = Int.random(in: 0..<100000)
    uniqueRandomNumbers.insert(value)
}

//
//Additionally, this post presents Swift random generator examples for the following types:
//Random Bool
Bool.random()
// Example Output: false

// Random CGFloat
CGFloat.random(in: 0..<3.14159)
// Example Output: 2.191631039096155

//Random Color
UIColor(
    hue: CGFloat.random(in: 0..<1),
    saturation: CGFloat.random(in: 0..<1),
    brightness: CGFloat.random(in: 0..<1),
    alpha: 1.0
)
// Example Output:
// Red: 0.088
// Green: 0.118
// Blue: 0.953
// Alpha: 1.0

//Random Data
let bytes = (0..<10).map { _ in
    UInt8.random(in: 0...UInt8.max)
}
Data(bytes)
// Output is 10 bytes

//Random Date
let yearSeconds = 60 * 60 * 24 * 365.0
let timeInterval = Double.random(in: 0..<yearSeconds)

// Random date between now and one year from now
Date(timeInterval: timeInterval, since: Date())
// Example Output: Jul 20, 2021 at 1:47

//Random Double
Double.random(in: 0..<3.14159)
// Example Output: 2.37669589020634

//Random Enum
enum Assignment {
    case coding
    case debugging
    case ui
    case testing
    case documentation
    case refactoring
}

// enum Assignment: CaseIterable {
// or
extension Assignment: CaseIterable {}
    
Assignment.allCases.randomElement()
// Example Output: .testing
    
//Random Float
Float.random(in: 0..<3.14159)
// Example Output:0.9225707

//Random Int
Int.random(in: 0..<100)
// Example Output: 91

//Random String
let letters = "abcdefghijklmnopqrstuvwxyz"
print(String((0..<10).map { _ in letters.randomElement()! }))
// Example Output: aiwlguezgw

// Random UUID
print(UUID().uuidString)
// Example Output:
// 25A4DA38-743C-46D0-9B71-1699556C975E
