import UIKit

var str = "I love penguins"

var strLong = [String](repeating: "I love penguins", count: 1000)
var nsstringLong = [NSString](repeating: "I love penguins", count: 1000)

// 29018 Bytes
var objcLongSecure = try! NSKeyedArchiver.archivedData(
    withRootObject: strLong, requiringSecureCoding: true)

// 18001 Bytes
var jsonEnc = try! JSONEncoder().encode(strLong)

// 6290 Bytes
var objcContainer = try! NSKeyedArchiver.archivedData(
    withRootObject: nsstringLong, requiringSecureCoding: true)

// 18001 Bytes
var jsonContainer = try! JSONEncoder().encode(nsstringLong as [String])



//// 155 Bytes
//var objcNonSecure = try! NSKeyedArchiver.archivedData(
//    withRootObject: str, requiringSecureCoding: false)
//
//// 155 Bytes
//var objcSecure = try! NSKeyedArchiver.archivedData(
//    withRootObject: str, requiringSecureCoding: true)
//
//String(data: objcSecure, encoding: .ascii)
//
//class Container: NSObject, Codable, NSCoding, NSSecureCoding {
//    func encode(with coder: NSCoder) {
//        coder.encode(text, forKey: "text")
//    }
//
//    required init?(coder: NSCoder) {
//        text = coder.decodeObject(forKey: "text") as! String
//    }
//
//    static var supportsSecureCoding: Bool = true
//
//    var text: String
//
//    init(text: String) {
//        self.text = text
//    }
//}
//
////class Container with Secure Coding {
////    var text: String
////}
//
//var strLong = [String](repeating: "I love penguins", count: 1000)
//var containerLong = [Container](repeating: Container(text: "I love penguins"), count: 1000)
//
//// 29018 Bytes
//var objcLongSecure = try! NSKeyedArchiver.archivedData(
//    withRootObject: strLong, requiringSecureCoding: true)
//
//// 18001 Bytes
//var jsonEnc = try! JSONEncoder().encode(strLong)
//
//// 6394 Bytes
//var objcContainer = try! NSKeyedArchiver.archivedData(
//    withRootObject: containerLong, requiringSecureCoding: true)
//
//// 27001 Bytes
//var jsonContainer = try! JSONEncoder().encode(containerLong)
//
//
//class Penguin: NSObject, Codable, NSCoding, NSSecureCoding {
//    func encode(with coder: NSCoder) {
//        coder.encode(name, forKey: "name")
//        coder.encode(birthplace, forKey: "birthplace")
//        coder.encodeCInt(Int32(height), forKey: "height")
//        coder.encodeCInt(Int32(width), forKey: "width")
//    }
//
//    required init?(coder: NSCoder) {
//        name = coder.decodeObject(forKey: "name") as! String
//        birthplace = coder.decodeObject(forKey: "birthplace") as! String
//        height = coder.decodeInteger(forKey: "height")
//        width = coder.decodeInteger(forKey: "width")
//    }
//
//    static var supportsSecureCoding: Bool = true
//
//    var name: String
//    var birthplace: String
//    var height: Int
//    var width: Int
//
//    init(name: String, birthplace: String, height: Int, width: Int) {
//        self.name = name
//        self.birthplace = birthplace
//        self.height = height
//        self.width = width
//    }
//}
//
////class Penguin with Secure Coding {
////    var name: String
////    var birthplace: String
////    var height: Int
////    var width: Int
////}
//
//var copies = [Penguin](
//    repeating: Penguin(
//        name: "Christian",
//        birthplace: "South Pole",
//        height: 35,
//        width: 1
//    ),
//    count: 1000
//)
//
//// 6451 Bytes
//var objcCopies = try! NSKeyedArchiver.archivedData(
//    withRootObject: copies, requiringSecureCoding: true)
//
//// 69001 Bytes
//var jsonCopies = try! JSONEncoder().encode(copies)
//
//var raft: [Penguin] = []
//for i in 0..<1000 {
//    raft.append(Penguin(
//        name: "Christian",
//        birthplace: "South Pole",
//        height: i,
//        width: 1
//    ))
//}
//
//// 77874 Bytes
//var objcRaft = try! NSKeyedArchiver.archivedData(
//    withRootObject: raft, requiringSecureCoding: true)
//
//// 69891 Bytes
//var jsonRaft = try! JSONEncoder().encode(raft)
