//
//  ViewController.swift
//  blog-tests
//
//  Created by Robert Pieta on 1/2/21.
//  Copyright © 2021 ZealousAmoeba. All rights reserved.
//

import UIKit

// TARGET:
// Swift Optional Protocol Methods
//@objc protocol ViewActionDelegate {
//    @objc optional func ignoreActions() -> Bool
//}

enum ViewState {
    case `default`
    case editting
    case loading
}

enum ViewAction {
    case edit
    case save
    case cancel
}

protocol ViewActionDelegate {
    var state: ViewState { get }
    var userID: String? { get set }

    var errorHandler: ((Error) -> Void)? { get set }
    
    func handle(action: ViewAction)
}

extension ViewActionDelegate {
    var isReadyForNextAction: Bool {
        return state != .loading
    }
}

class ActionController {
    var state: ViewState = .default
    var userID: String?
    var errorHandler: ((Error) -> Void)?
}

extension ActionController: ViewActionDelegate {
    func handle(action: ViewAction) {
        switch action {
        case .edit:
            break
        case .save:
            break
        case .cancel:
            break
        }
    }
}

class ActionView: UIView {
    var delegate: ViewActionDelegate?

    @IBAction func save() {
        guard let delegate = delegate else { return }
        guard delegate.isReadyForNextAction else { return }

        // optional
        // guard !delegate.ignoreActions() else { return }
        
        delegate.handle(action: .save)
    }
    
    func handle(error: Error) {
        delegate?.errorHandler?(error)
    }
}

class ActionViewController: UIViewController {
    var actionView = ActionView()
    var actionController = ActionController()
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        actionController.userID = "@robert"
        actionController.errorHandler = { (error) in
            // Handle error
        }
        
        actionView.delegate = actionController
    }
}









class ViewController: UIViewController {
    // Parallel Loops
    func expensiveWork(count: Int) -> Int {
        Thread.sleep(forTimeInterval: TimeInterval(count))
        return count + 1
    }
    
    func expensiveWork(count: Int, completion: @escaping ((Int) -> Void)) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            completion(count+1)
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Sleeping a thread in Swift
         Thread.sleep(forTimeInterval: 1)
        // Thread.sleep(until: Date() + 1)
        
        // Call performTask after a delay of 1 second
//        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
//            performTask()
//        }
        
        
        // Parallel for loop - Synchronous, target dispatch queue paralle
        // LINK TO EXISTING PARALLEL API REQUESTS ARTICLE
        let work = [1, 2, 1, 2, 1, 1]
        var results = [0, 0, 0, 0, 0, 0]

        var start = CACurrentMediaTime()
        DispatchQueue.concurrentPerform(iterations: work.count) { (index) in
           results[index] = expensiveWork(count: work[index])
        }
        var delta = CACurrentMediaTime() - start

        print(results)
        print(delta)

        // Parallel for loop asynchronous (target dispatch group swift)
        start = CACurrentMediaTime()
        let group = DispatchGroup()
            
        for index in 0..<work.count {
            group.enter()
            expensiveWork(count: work[index]) { (result) in
                results[index] = result
                group.leave()
            }
        }
        
        group.notify(queue: .main) {
            delta = CACurrentMediaTime() - start
            print(results)
            print(delta)
        }

        print("should be before async results")
    }
}



// TARGET:
// Get User Location In Swift, Real-Time, Coordinate

// TARGET Location Always and Location When In Use
// DOCUMENT
// Privacy - Location Always and When In Use Usage Description
// Privacy - Location When In Use Usage Description
//
// This app uses your location to personalize your app experience.

import CoreLocation

class MyLocationViewController: UIViewController {
    private lazy var locationManager: CLLocationManager = {
        let locationManager = CLLocationManager()
        locationManager.delegate = self
        return locationManager
    }()
    
    func startUpdatingUserLocation() {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedAlways:
            locationManager.startUpdatingLocation()

        case .authorizedWhenInUse:
            locationManager.startUpdatingLocation()

        case .denied:
            break
        case .notDetermined:
            locationManager.requestAlwaysAuthorization()
            //locationManager.requestWhenInUseAuthorization()

        case .restricted:
            break
        }
    }
    
    func stopUpdatingUserLocation() {
        locationManager.stopUpdatingLocation()
    }
}

extension MyLocationViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch CLLocationManager.authorizationStatus() {
        case .authorizedAlways:
            locationManager.startUpdatingLocation()

        case .authorizedWhenInUse:
            locationManager.startUpdatingLocation()

        default:
            locationManager.stopUpdatingLocation()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            let latitude = location.coordinate.latitude
            let longitude = location.coordinate.longitude
            
            // Handle location update
        }
    }
}



// let vs var in Swift [Swift 5 Examples]
// var in Swift
// let in Swift
// Difference between var and let in Swift
// When to use var instead of let in Swift
// When to use let instead of var in Swift
//
//func code() {
//    // Initialize an immutable countConstant
//    let countConstant = 0
//
//    //
//    countConstant = 1
//
//    // Initialize an immutable numbersConstant
//    let numbersConstant = [1, 2]
//
//    numbersConstant = []
//
//    numbersConstant.append(3)
//
//    // Define Counter
//    struct Counter {
//        var value: Int
//
//        mutating func increment() {
//            self.value = self.value + 1
//        }
//    }
//
//    // Initialize an immutable Counter
//    let counter = Counter(value: 0)
//
//    counter = Counter(value: 1)
//
//    counter.increment()
//
//    class Counter2 {
//        var value: Int
//
//        init(value: Int) {
//            self.value = value
//        }
//
//        func increment() {
//            self.value = self.value + 1
//        }
//    }
//
//    // Both
//    var counter3 = Counter2(value: 0)
//    counter3.increment()
//    counter3 = Counter2(value: 1)
//
//    let counter4 = Counter2(value: 0)
//    counter4.increment()
//    counter4 = Counter2(value: 1)
//
//}

// When to use Guard in Swift [Updated for Swift 5]
// Guard in Swift
// Throw errors with Guard in Swift
// Unwrap optionals with Guard in Swift
// Verify requirements or exit early with Guard in Swift
// Check iOS version compatibility with Guard in Swift
//
//enum ValidationError: Error {
//    case fullNameIsRequired
//    case lastNameIsRequired
//}
//
//func code() {
//    let nameTextField: UITextField? = UITextField()
//
//    func validate(name: String) throws {
//        guard name.count > 3 else {
//            throw ValidationError.fullNameIsRequired
//        }
//
//        guard name.contains(" ") else {
//            throw ValidationError.lastNameIsRequired
//        }
//    }
//
//    func submitForm() {
//        // Unwraps two options with one gaurd statement,
//        // nameTextField and the String? text on nameTextField
//        guard let name = nameTextField?.text else {
//            return
//        }
//
//        // Handle for submission
//    }
//
//    var hasEdits = false
//    var forceSave = false
//
//    func saveData() {
//        guard hasEdits || forceSave else {
//            return
//        }
//
//        // Handle data saving
//    }
//
//    enum Camera {
//        case wideAngle
//        case telephoto
//    }
//    class MyCameraViewController: UIViewController {
//        var camera: Camera = .wideAngle
//    }
//
//    class VC: UIViewController {
//        func showTelephotoCamera() throws {
//            guard #available(iOS 13, *) else {
//                throw CameraError.deviceNotSupported
//            }
//
//            let cameraController = MyCameraViewController()
//            cameraController.camera = .telephoto
//            present(cameraController, animated: true, completion: nil)
//        }
//    }
//}


// When to use Defer in Swift [Updated for Swift 5]
// Defer in Swift
// Close files using Defer in Swift
// Release locks using Defer in Swift
// Call completion blocks using Defer in Swift

//func code() {
//    enum WriteError: Error {
//        case notFound
//    }
//
//    func write(data: Data, offset: Int) throws {
//        let documentsPath = NSSearchPathForDirectoriesInDomains(
//            .documentDirectory,
//            .userDomainMask,
//            true
//        )[0]
//
//        let filename = "data.txt"
//        let filepath = "\(documentsPath)/\(filename)"
//
//        guard let file = FileHandle(forUpdatingAtPath: filepath) else {
//            throw WriteError.notFound
//        }
//
//        // Ensure the file is closed at the end of this function
//        defer {
//            try? file.close()
//        }
//
//        // Seek to specified offset
//        try file.seek(toOffset: UInt64(offset))
//
//        // Write data at specified offset
//        file.write(data)
//    }
    
//    var lock = NSLock()
//
//    func criticalSectionWork(task: Task) -> Int {
//        lock.lock()
//
//        // lock.unlock() will always be called before
//        // the return statement
//        defer {
//            lock.unlock()
//        }
//
//        // Handle results
//        let result = task.perform()
//
//        if result == .success { return 0 }
//        else if result == .error { return 1 }
//        else { return 2 }
//    }
    
//    func process(tasks: [Tasks], completion: ([Int]?, Error?) -> Void) {
//        var results = [Int]()
//        var error: Error?
//
//        // completion will be always executed when this function ends,
//        // even if there are multiple branches of logic later in the
//        // function implementation
//        defer {
//            completion(results, error)
//        }
//
//        for task in tasks {
//            do {
//                results.append(task.perform())
//            }
//            catch let taskError {
//                error = taskError
//                break
//            }
//        }
//
//        if let error = error {
//            results = nil
//        }
//    }
//}

